package cache

import "testing"

func TestHandlerPaging(t *testing.T) {
	//disable := []string{"com.dealspure.wild", "com.groundhog.mcpemaster", "ru.zdevs.zarchiver", "com.google.android.play.games", "com.newapp.gamekiller", "org.hola com.gmail.heagoo.apkeditor", "com.CraftingMax.Explore", "com.rarlab.rar", "org.ppsspp.ppsspp", "com.nekki.shadowfight", "com.supercell.clashroyale", "com.firsttouchgames.dls3", "com.nianticlabs.pokemongo", "com.lenovo.anyshare.gps", "com.kiloo.subwaysurf", "com.roblox.client", "com.firsttouchgames.story"}
	//HandlerPaging(, 1, 0, disable, 1, "com.dealspure.wild", false)

}
